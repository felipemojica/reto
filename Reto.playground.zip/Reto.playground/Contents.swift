//: Playground - noun: a place where people can play

import UIKit


var numero = 0...100

for num in numero {
    
    if(num % 5 == 0 && num != 0){
        print("\(num) Bingo!!!")
        
    }else if( 30 <= num && num <= 40)
    {
        print("\(num) Viva Swift!!!")
    }
    else if(num % 2 == 0){
    print("\(num) Par!!!")
    }
    else{
        print("\(num) inpar!!!")
    }
    
}
